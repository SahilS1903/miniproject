import pandas as pd
import numpy as np
import joblib
import ipaddress
from sklearn.metrics import accuracy_score
import glob

# Load preprocessing objects
scaler = joblib.load("preprocessing/scaler.pkl")
feature_columns = joblib.load("preprocessing/feature_columns.pkl")

# Load label encoders
encoders = {
    "Proto": joblib.load("preprocessing/Proto_encoder.pkl"),
    "State": joblib.load("preprocessing/State_encoder.pkl"),
}

# Load models
def load_model(model_name):
    files = glob.glob(f"models/ctu_{model_name}_*.pkl")  
    if files:
        model_obj = joblib.load(files[0])  
        return model_obj["model"] if isinstance(model_obj, dict) and "model" in model_obj else model_obj
    else:
        raise FileNotFoundError(f"No model file found for pattern: models/{model_name}_*.pkl")

# Load models dynamically
models = {
    "Random Forest": load_model("random_forest"),
    "XGBoost": load_model("xgboost"),
    "SVM": load_model("svm"),
    "KNN": load_model("knn"),
    "Logistic Regression": load_model("logistic_regression"),
}

# Load test data (2000 bot samples)
print("📂 Loading test data...")
df_bots = pd.read_csv("test_data.csv")
df = df_bots[df_bots["Label"] == 1].sample(n=2000, random_state=42)

# Separate actual labels
actual_labels = df["Label"].values
df = df.drop(columns=["Label"])

# Show actual label counts
actual_counts = pd.Series(actual_labels).value_counts().sort_index()
print("\n🔹 Actual Label Counts:\n", actual_counts)

# Convert categorical features
for col in encoders:
    if col in df.columns:
        df[col] = encoders[col].transform(df[col])

# Convert IP addresses to numerical
def ip_to_int(ip):
    try:
        return int(ipaddress.ip_address(ip))
    except ValueError:
        return np.nan

for col in ["SrcAddr", "DstAddr"]:
    df[col] = df[col].apply(ip_to_int)

# Convert hex values
def hex_to_int(value):
    try:
        return int(value, 16) if isinstance(value, str) and value.startswith("0x") else value
    except ValueError:
        return np.nan

for col in df.columns:
    df[col] = df[col].apply(hex_to_int)

# Convert all to numeric, handling missing values
df = df.apply(pd.to_numeric, errors="coerce")
df.fillna(df.median(), inplace=True)

# Select only relevant columns
df = df[feature_columns]

# Scale features
X_test_scaled = scaler.transform(df)

# Predict using each model
print("\n📊 Model Predictions:")
results = {}
for name, model in models.items():
    y_pred = model.predict(X_test_scaled)
    
    # Count predicted labels
    predicted_counts = pd.Series(y_pred).value_counts().sort_index()
    
    # Display results
    accuracy = accuracy_score(actual_labels, y_pred)
    results[name] = accuracy
    print(f"\n🔹 {name} Accuracy: {accuracy:.4f}")
    print("   🔸 Predicted Label Counts:\n", predicted_counts)

# Print best model
best_model = max(results, key=results.get)
print(f"\n🏆 Best Model: {best_model} with {results[best_model]:.4f} accuracy")

print("\n✅ Prediction Complete!")

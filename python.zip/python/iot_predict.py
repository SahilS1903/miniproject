import pandas as pd
import joblib
import glob
from sklearn.metrics import accuracy_score

# Load preprocessing objects
print("📂 Loading preprocessing objects...")
scaler = joblib.load("preprocessing/scaler.pkl")
feature_columns = joblib.load("preprocessing/feature_columns.pkl")

# Load encoders
encoders = {}
for col in ["Proto", "State"]:
    encoders[col] = joblib.load(f"preprocessing/{col}_encoder.pkl")

# Load test data
print("📂 Loading IoT test data...")
df = pd.read_csv("iot_final.csv").sample(n=1000, random_state=22)

# Separate actual labels
actual_labels = df["Label"].values
df = df.drop(columns=["Label"])  # Remove label column before prediction

# Apply categorical encoding
for col in encoders:
    if col in df.columns:
        df[col] = encoders[col].transform(df[col])

# Ensure test data has the same features as training
df = df[feature_columns]

# Apply scaling
df_scaled = scaler.transform(df)

# Load best model dynamically
def load_best_model(model_name):
    files = glob.glob(f"models/iot_{model_name}_*.pkl")
    if files:
        best_model = max(files, key=lambda x: float(x.split("_")[-1].replace(".pkl", "")))  # Select highest accuracy
        return joblib.load(best_model)
    else:
        raise FileNotFoundError(f"No model file found for pattern: models/{model_name}_*.pkl")

# Load models
models = {
    "Random Forest": load_best_model("random_forest"),
    "XGBoost": load_best_model("xgboost"),
    "SVM": load_best_model("svm"),
    "KNN": load_best_model("knn"),
    "Logistic Regression": load_best_model("logistic_regression"),
}

# Show actual label counts
print("\n🔹 Actual Label Counts:\n", pd.Series(actual_labels).value_counts().sort_index())

# Predict using each model
print("\n📊 Model Predictions:")
results = {}
for name, model in models.items():
    y_pred = model.predict(df_scaled)
    
    # Count predicted labels
    predicted_counts = pd.Series(y_pred).value_counts().sort_index()

    # Display results
    accuracy = accuracy_score(actual_labels, y_pred)
    results[name] = accuracy
    print(f"\n🔹 {name} Accuracy: {accuracy:.4f}")
    print("   🔸 Predicted Label Counts:\n", predicted_counts)

# Print best model
best_model = max(results, key=results.get)
print(f"\n🏆 Best Model: {best_model} with {results[best_model]:.4f} accuracy")

print("\n✅ Prediction Complete!")
